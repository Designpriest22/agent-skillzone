MEAT & GREET x FIRSTKLAZ - INSTAGRAM CAROUSEL
8 slides, 1080 x 1350 px (4:5). Post in number order, 01 to 08.

PNG/            Lossless masters
JPG_Instagram/  Upload these (sRGB, quality 95, no extra compression)

Event: Saturday 31 October · Doxa Park, Abuja · 5PM · 18+
Tickets: pv.rsvp/firstklaz-meating (also put this in the caption and the bio; links in images can't be tapped)
