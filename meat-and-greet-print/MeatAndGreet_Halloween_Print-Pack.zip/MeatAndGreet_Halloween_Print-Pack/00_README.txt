MEAT & GREET - HALLOWEEN BBQ PARTY - PRINT PACK
Saturday 31 October - a TCM production
=====================================================================

ARTWORK DEADLINE: Wednesday 28 October, so print lands for the Friday site build.

START HERE
  00_Proof-Book.pdf            Visual proof of every item + spec, print schedule, brand system
  00_Overview_All-Designs.jpg  Every design on one sheet
  00_Print-Schedule.csv        Item / file / size / bleed / qty / material - send to the printer

FOLDERS (numbers match the print checklist)
  01_Signage      items 01-10   arch, stage backdrop (+ LED still), skull banners, perimeter,
                                brush backdrop, floor plan board, zone signs, directional,
                                house rules, fence boards
  02_Menus        items 11-13   coffin grill menu (+ dieline), bar menus, token boards
  03_Access       items 14-20   wristbands, numbered case cards, tokens, VIP tents,
                                coffin table numbers 1-24, crew passes, media passes
  04_Activations  items 21-30   height chart, charge placards, photo overlay (PNG),
                                Suspects header + 10 WANTED posters, Released cards,
                                balloon darts wrap, knife target, Jar of Heads template,
                                specimen labels, costume contest tags
  05_Decor        items 31-35   hazard decals, ghost balloon cut file (PDF + SVG), bottle
                                labels, IV-bag labels, sponsor lockup frames
  06_Crew         items 36-37   crew pack (6pp A4), radio call sheet
  _source         Build scripts + fonts. Change data (prices, counts, copy) and rebuild.

FILE FORMAT
  - Print-ready PDF, RGB, fonts embedded, type and shapes vector. Textures are image layers.
  - Bleed is built into the page; TrimBox/BleedBox are set, so the RIP knows where to cut.
  - Files over ~3 m are supplied at 1:10 (filename says SCALE-1to10): output at 1000%.
  - Shaped items (coffin menu, coffin table numbers, tokens, knife target) carry a separate
    dieline page: 100% magenta hairline = cut, cyan dash = fold.
  - Printers converting to CMYK: keep the reds rich (Blood red #B3121C, Ember #E0592A).

BEFORE YOU SEND - CONFIRM THESE
  1. Token costs and naira prices (menus + token boards print as write-on circles/lines until set).
  2. Capacity -> case card count (file has 0001-0500), costume tags (001-100).
  3. Sponsor artwork: placeholders on perimeter panel D, bar menus and lockup frames must be
     replaced with supplied files, unaltered.
  4. Venue times -> run of show uses "T = doors"; radio channels/codes are a proposal.
  5. Toilets / first aid positions -> add to the floor plan once known.
  6. Existing balloon-dart board size (file assumes 1220 x 2440 mm).
  7. Hashtag on the Released card (#MEATANDGREET) and house-rules wording.
  8. Logo was redrawn from the deck artwork as flat vector; swap in the master vector if you have it.

RULES THE DESIGN FOLLOWS (from the event plan)
  Red light and haze do the theming. No purple or green. Fun-scary, never gory.
  Every prop flame is LED. Impact/Anton for headlines and wayfinding; hand-painted brush for
  signage. Safety and facilities signs stay clean and high-contrast.
